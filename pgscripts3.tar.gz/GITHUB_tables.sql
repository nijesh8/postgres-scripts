CREATE_tables.sql


-- https://learn.microsoft.com/en-us/azure/cosmos-db/postgresql/quickstart-distribute-tables

CREATE TABLE github_users
(
	user_id bigint,
	url text,
	login text,
	avatar_url text,
	gravatar_id text,
	display_login text
);

CREATE TABLE github_events
(
	event_id bigint,
	event_type text,
	event_public boolean,
	repo_id bigint,
	payload jsonb,
	repo jsonb,
	user_id bigint,
	org jsonb,
	created_at timestamp
);

CREATE INDEX event_type_index ON github_events (event_type);
CREATE INDEX payload_index ON github_events USING GIN (payload jsonb_path_ops);


SELECT create_distributed_table('github_users', 'user_id');
SELECT create_distributed_table('github_events', 'user_id');

-- download users and store in table
COPY github_users FROM 'https://pgquickstart.blob.core.windows.net/github/users.csv.gz';

-- download events and store in table
COPY github_events FROM 'https://pgquickstart.blob.core.windows.net/github/events.csv.gz';



-- TEST queries
-- https://learn.microsoft.com/en-us/azure/cosmos-db/postgresql/quickstart-run-queries

1.
-- count all rows (across shards)
SELECT count(*) FROM github_users;

2.
-- Find all events for a single user.
-- (A common transactional/operational query)
SELECT created_at, event_type, repo->>'name' AS repo_name
  FROM github_events
 WHERE user_id = 3861633;

3.
-- More complicated queries
-- Here's an example of a more complicated query, which retrieves hourly statistics for push events on GitHub.
-- It uses PostgreSQL's JSONB feature to handle semi-structured data.

-- Querying JSONB type. Query is parallelized across nodes.
-- Find the number of commits on the default branch per hour

SELECT date_trunc('hour', created_at) AS hour,
       sum((payload->>'distinct_size')::int) AS num_commits
FROM   github_events
WHERE  event_type = 'PushEvent' AND
       payload @> '{"ref":"refs/heads/master"}'
GROUP BY hour
ORDER BY hour;

4.
-- DDL commands that are also parallelized
ALTER TABLE github_users ADD COLUMN dummy_column integer;

