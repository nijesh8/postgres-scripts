#!/bin/bash


while(true); do

sleep 1
date
pg_autoctl show settings
pg_autoctl show state
psql << EOF
select pid, application_name, state, sync_state, sent_lsn, write_lsn, flush_lsn,replay_lsn, write_lag, flush_lag , replay_lag, sync_priority, reply_time from pg_stat_replication ;
\q
EOF

echo "From MONITOR Database:"
echo "==========================="
date
echo

uri=`pg_autoctl show uri | grep monitor | cut -d"|" -f3 | xargs`
psql $uri << EOF
select nodename, reporttime, healthchecktime, reportedtli, reportedlsn, walreporttime, statechangetime, candidatepriority, replicationquorum from pgautofailover.node order by nodename ;
\q
EOF

done
