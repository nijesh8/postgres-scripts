while(true) ;
do
	 echo "###################################################";
	 ls -tlr $PGDATA/log | tail -4 ; echo ;
	 LASTLOG=`ls  -tr $PGDATA/log | tail -1 `
	 echo "Tailing " $LASTLOG
	 echo; echo "================================================================="
	 tail -10 $PGDATA/log/$LASTLOG ; echo;
	 sleep 2;

	date
	echo; echo "SESSION List:"
	echo "================================================================="

	psql << EOF
	select pid, datname, usename, application_name, client_addr, backend_start , state, substr(query,1,20) QRY , backend_type from
pg_stat_activity
	where usename is not null
	and backend_type not in ('walsender' )
	and backend_type in ( 'client backend' )
	and application_name not in ( 'psql' )
;
\q
EOF
done
