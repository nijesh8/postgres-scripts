
\! echo ; echo Status of Replication Slots; echo "=================================================="  ; echo
select * from pg_replication_slots ;

\x
\! echo ; echo [ In STANDBY ] Status of WAL Receiver ; echo "=================================================="  ; echo
select * from pg_stat_wal_receiver ;


\! echo ; echo [ In PRIMARY ] Status of WAL Replication ; echo "=================================================="  ; echo
select * from pg_stat_replication ;
