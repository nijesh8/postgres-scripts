while(true)
do
sleep 0.25
echo; echo "Call script.."
date ; ./HAtester_lag_stats_pgzktest1_LVS.py 5000 ; date

done
